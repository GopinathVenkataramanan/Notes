
# Complete Kiro Enterprise Platform

Open-source SaaS starter architecture.

Stack:
- Turborepo
- pnpm
- Next.js
- Expo
- Hono
- PostgreSQL
- Drizzle
- Better Auth
- Redis/Valkey
- MinIO
- Docker
- Kubernetes
- Prometheus
- Grafana
- Loki
- GlitchTip
- Traefik
- GitHub Actions
