# Devops-Engineer

Enterprise Kiro standard for devops-engineer.

## Objectives
- Scalability
- Security
- Maintainability
- Cloud agnostic deployment

## Standards
- TypeScript first
- Docker first
- Kubernetes ready
- PostgreSQL + Drizzle
- Hono API
- Next.js + Expo
