# pre-implementation

Hook definition and workflow.