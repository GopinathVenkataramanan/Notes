# openapi-sync

Hook definition and workflow.