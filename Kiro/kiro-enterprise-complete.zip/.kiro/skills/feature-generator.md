# Feature-Generator

Enterprise Kiro standard for feature-generator.

## Objectives
- Scalability
- Security
- Maintainability
- Cloud agnostic deployment

## Standards
- TypeScript first
- Docker first
- Kubernetes ready
- PostgreSQL + Drizzle
- Hono API
- Next.js + Expo
