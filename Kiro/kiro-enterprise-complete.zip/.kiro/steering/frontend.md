# Frontend

Enterprise Kiro standard for frontend.

## Objectives
- Scalability
- Security
- Maintainability
- Cloud agnostic deployment

## Standards
- TypeScript first
- Docker first
- Kubernetes ready
- PostgreSQL + Drizzle
- Hono API
- Next.js + Expo
