# Kiro Enterprise Setup Guide

Open-source SaaS platform using Turborepo, Next.js, Expo, Hono, PostgreSQL, Drizzle, Better Auth, Docker and Kubernetes.