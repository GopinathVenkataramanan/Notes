# Architecture Standards

- Cloud agnostic
- Docker first
- Kubernetes ready
- Next.js + Expo + Hono
- PostgreSQL + Drizzle
- Better Auth
- Redis/Valkey
- MinIO