# Authentication

Better Auth with email/password, OAuth, passkeys, organizations, sessions and roles.