# Database Standards

- PostgreSQL
- Drizzle ORM
- UUID primary keys
- Audit fields
- Tenant isolation