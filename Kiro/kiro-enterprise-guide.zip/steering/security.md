# Security Standards

- OWASP Top 10
- Zod validation
- Infisical secrets
- RBAC
- MFA support
- Trivy and Semgrep scanning