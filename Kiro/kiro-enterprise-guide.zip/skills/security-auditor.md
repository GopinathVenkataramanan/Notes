# Security Auditor Skill

Review authentication, authorization, secrets, dependencies and vulnerabilities.