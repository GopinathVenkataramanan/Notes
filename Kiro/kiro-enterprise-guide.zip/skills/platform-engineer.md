# Platform Engineer Skill

Generate Dockerfiles, compose files, health checks, backups, Helm charts and deployment manifests.