# Open Source Architect Skill

Prefer open standards, Docker, Kubernetes, PostgreSQL, Redis and MinIO. Avoid vendor lock-in.