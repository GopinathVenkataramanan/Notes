# DevOps Engineer Agent

Owns CI/CD, containers, Kubernetes and observability.