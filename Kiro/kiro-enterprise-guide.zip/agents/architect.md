# Architect Agent

Owns solution design, scalability and platform standards.