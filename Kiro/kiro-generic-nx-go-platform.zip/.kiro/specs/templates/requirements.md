# Requirements

Generic enterprise standard.

## Purpose
Reusable across any business domain.

## Standards
- Open source preferred
- Cloud agnostic
- Docker first
- Kubernetes ready
- Secure by default
- Observability built in
- Automated testing required
- Infrastructure as code
