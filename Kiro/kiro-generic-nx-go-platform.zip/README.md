
# Generic Enterprise Kiro Platform Blueprint

A domain-neutral Kiro configuration package designed for any future application.

## Technology Baseline
- Nx Monorepo
- pnpm Workspaces
- Next.js
- Expo React Native
- Go + Gin
- PostgreSQL
- Ent ORM
- Keycloak
- Docker
- Kubernetes
- GitHub Actions

## Included
- Steering files
- Skills
- Agents
- Hooks
- Spec templates

This package intentionally avoids business-specific logic and can be reused for SaaS, ERP, CRM, eCommerce, healthcare, logistics, fintech, internal platforms, and other enterprise applications.
